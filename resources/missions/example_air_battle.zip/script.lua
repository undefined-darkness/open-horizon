--Open-Horizon mission script

local enemy_count = 0

function init()
    setup_radio("ally", "Motorjaw", "blue")
    setup_radio("enemy", "Enemy", "red")
    add_radio("ally", "OK, let's do this!", 4)
    add_radio("enemy", "Oh noes! It's the one-winged ghosts of moebius!\nWe're all doomed!", 4)
    add_radio("ally", "Wow! Looks like we're getting popular", 4)
end

function enemy_add(id)
  enemy_count = enemy_count + 1
end

function enemy_kill(id)
  enemy_count = enemy_count - 1

  if (enemy_count == 3) then
    add_radio("ally", "Three to go", 4);
  elseif (enemy_count == 1) then
    add_radio("ally", "Only one left", 4);
  elseif (enemy_count <= 0) then
    mission_clear()
    add_radio("ally", "Good game", 6);
  end
end
