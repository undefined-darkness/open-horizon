--Open-Horizon mission script

local enemies_count = 0

function init()
  setup_radio("ally", "Ally", "blue")
  add_radio("ally", "Prevent attack on the airport", 4)
end

function on_fail(id)
  if string.find(id, "enemy") then
    add_radio("ally", "Enemy forces entered the airport area", 4)
    mission_fail()
  end
end

function add_enemy(id)
  enemies_count = enemies_count + 1
end

function kill_enemy(id)
  enemies_count = enemies_count - 1

  if enemies_count <= 0 then
    add_radio("ally", "Good job!", 4)
    mission_clear()
  end
end
