--Open-Horizon mission script

function init()
  setup_radio("ally1", "Karkov", "blue")
  setup_radio("ally2", "Zubov", "blue")

  add_radio("ally1", "We must not retreat, there is no land \nfor us beyond the capital!", 5)

  set_speed_limit("bomber", 500)
end

local ground_in = 0

function on_defend_zone(id)
  if string.find(id, "ground") then
    ground_in = ground_in + 1

    if ground_in ==1 then
      add_radio("ally1", "Enemy is breaking the city perimeter.", 4)
    end

    if ground_in > 3 then
      add_radio("ally1", "We have failed.", 4)
      mission_fail()
    end
  end

  if string.find(id, "bomber") then
      add_radio("ally1", "Bombers broke the perimeter!", 4)
      mission_fail()
  end
end

local ground_kill = 0

function on_kill(id)
  ground_kill = ground_kill + 1

  if ground_kill == 1 then
    add_radio("ally1", "Good kill! We'll take the air targets", 4)
  end
  
  if ground_kill ==12 then
    add_radio("ally2", "They have sent the bombers! Take them down", 6)
    set_active("bomber", true)
    mission_update()
  end
end

local raptors_down = 0

function raptor_down(id)
  raptors_down = raptors_down + 1

    add_radio("ally1", "Raptor down!", 3)
  
  if raptors_down == 1 then
    add_radio("ally2", "He saw his death in a dreams many times", 5)
  end
  
  if raptors_down == 3 then
    add_radio("ally2", "They never attack the same place twice\nThey were testing the defence for weaknesses,\n systematically. They remember.", 5)
  end
end

local bombers_down = 0

function bomber_down(id)
  bombers_down = bombers_down + 1

  if bombers_down == 1 then
    add_radio("ally2", "There go 2 billion dollars. You totally wasted it!", 4)
    add_radio("ally1", "They wasted it when they built it", 4)
  end

  if bombers_down == 2 then
    add_radio("ally1", "Good pobeda, comrade.", 5)
    mission_clear()
  end
end
