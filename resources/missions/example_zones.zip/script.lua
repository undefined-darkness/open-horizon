--Open-Horizon mission script

function init()
    setup_radio("info", "Info", "white")
    add_radio("info", "Proceed to the first zone", 4)

    start_timer("fail_timer", 60, "on_fail")
    setup_timer("fail_timer", "Remaining")
end

function on_zone0(id)
    add_radio("info", "Proceed to the next zone", 4)
    set_active("skytree", false)
    set_active("akb", true)
end

function on_zone1(id)
    add_radio("info", "Proceed to the next zone", 4)
    set_active("akb", false)
    set_active("bamco", true)
end

function on_zone2(id)
    add_radio("info", "Proceed to the next zone", 4)
    set_active("bamco", false)
    set_active("tbs", true)
end

function on_zone3(id)
    set_active("tbs", false)
    mission_clear()
    stop_timer("fail_timer")
end

function on_fail()
    mission_fail()
end
