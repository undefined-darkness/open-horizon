--Open-Horizon mission script

local no_fire =  true

function init()
  setup_radio("captain", "Captain", "blue")

  add_radio("captain", "Nuggets! This is an intercept mission", 4)
  add_radio("captain", "Follow me and do not fire at the target", 4)

  set_speed("intruder", 1000)
  set_speed_limit("intruder", 1000)
  set_speed_limit("lead", 600)
end

function init_ally(id)
  set_target_search(id, "none")
end

function on_zone_ready(id)
  if (id == "intruder") then
    add_radio("captain", "Target is not responding. Get ready to intercept", 4)
    set_speed_limit("intruder", 1500)
    set_speed_limit("lead", 1500)
  end
end

function on_zone_enemy(id)
  if (id == "intruder") then
    clear_radio()
    add_radio("captain", "Engage!", 4)
    set_align("intruder", "target")
    set_follow("lead", "intruder")
    no_fire = false
  end
end

function on_zone_fail(id)
  if (id == "intruder") then
    clear_radio()
    add_radio("captain", "Target escaped", 4)
    mission_fail()
    set_align("intruder", "neutral")
  end
end

function on_target_kill(id)
    clear_radio()

  if (no_fire) then
    add_radio("captain", "The order was not to fire at the target!", 4)
    mission_fail()
  else
    add_radio("captain", "Nice kill!", 4)
    mission_clear()
  end
end
